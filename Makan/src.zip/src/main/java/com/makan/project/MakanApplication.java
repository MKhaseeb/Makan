package com.makan.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MakanApplication {

	public static void main(String[] args) {
		SpringApplication.run(MakanApplication.class, args);
	}

}
